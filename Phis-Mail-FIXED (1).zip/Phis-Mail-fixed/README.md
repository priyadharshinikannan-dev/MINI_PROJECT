# Phis-Mail — AI Phishing & Spam Detector

A Flask web application that detects phishing and spam emails using a **hybrid detection engine** combining rule-based analysis, URL inspection, and ML signals.

## Detection Engine

The new `app.py` uses a **multi-layer scoring system**:

| Layer | What it checks |
|-------|---------------|
| **Keyword rules** | 60+ weighted phishing/spam phrases (credential theft, urgency, banking scams, Indian-specific scams) |
| **URL analysis** | IP-based URLs, shorteners, typo-squatting, suspicious TLDs, insecure HTTP, excessive subdomains |
| **Urgency detection** | ALL-CAPS abuse, excessive `!`, alarm language |
| **Sensitive info requests** | OTP, CVV, password, banking detail requests |
| **Attachment flags** | `.exe`, `.vbs`, macro-enabled Office docs |
| **Brand impersonation** | PayPal, Google, SBI, HDFC, etc. |
| **Grammar patterns** | "Dear Customer", "Kindly verify", Indian phishing patterns |
| **ML signal** | Legacy SVC model as a lightweight tie-breaker |

Scores are mapped to probabilities via a sigmoid function. Verdicts:
- `< 35%` → **NOT SPAM / SAFE**
- `35–60%` → **SUSPICIOUS / MEDIUM RISK**
- `60–80%` → **SPAM / HIGH RISK**
- `> 80%` → **SPAM / CRITICAL RISK**

## Setup

```bash
pip install -r requirements.txt
python app.py
```

Open http://localhost:5000

## Test Cases

| Email | Expected |
|-------|----------|
| "Your account has been suspended. Verify immediately at http://secure-login-bank-update.com" | SPAM / CRITICAL RISK |
| "Congratulations! You won ₹5,00,000. Claim reward now" | SPAM |
| "URGENT: Your KYC update is pending. Enter OTP at sbi-kyc-update.xyz" | SPAM / CRITICAL RISK |
| "Meeting scheduled tomorrow at 10 AM" | SAFE |

## Deployment (Render)

1. Push to GitHub
2. Create new **Web Service** on [render.com](https://render.com)
3. Set start command: `gunicorn app:app`
4. Add `gunicorn` to `requirements.txt`

## File Structure

```
Phis-Mail-fixed/
├── app.py              ← Main detection engine (FIXED)
├── best_model.pkl      ← Legacy SVC model (used as auxiliary signal)
├── best_tfidf.pkl      ← TF-IDF vectorizer
├── templates/
│   └── template.html   ← Frontend UI (unchanged structure)
├── static/
│   └── styles.css
└── requirements.txt
```
